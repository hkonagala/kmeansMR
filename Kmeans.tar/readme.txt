Two mapreduce jobs are implemented: 

Distance Calculator
Centroid Calculator

Distance Calculatr is working perfectly.

Centroid Calculator have trouble printing the text into the output file.

The logic and the code is correct.

To run: Just copy the file Centroids.txt to /user/cloudera/harika/kmeans/centroids directoy in hdfs

The partial output can be seen when run.
